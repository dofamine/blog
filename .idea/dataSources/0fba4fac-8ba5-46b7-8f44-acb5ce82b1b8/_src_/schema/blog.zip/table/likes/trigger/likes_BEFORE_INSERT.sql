CREATE TRIGGER likes_BEFORE_INSERT
BEFORE INSERT ON likes
FOR EACH ROW
  BEGIN
	UPDATE `posts` SET `likes` = `likes` + 1 WHERE `id` = NEW.post_id;
END;
